def menuprincipal():
  login = int(input('''
|-------------------------------------------|
|     Menu principal                        |
|-------------------------------------------|
|  1  - Calcular moedas                     |
|  2  - Atualizar cotaçao                   |  
|-------------------------------------------|
'''))
  return login

def selecaoatumoeda():
  auti = int(input('''
  |----------------------------------------|
  | 1 - Atualizar cotação Dólares          | 
  | 2 - Atualizar cotação Euro             |
  | 3 - Atualizar cotação Peso Argentino   |
  | 99 - Desligar sistema                  |
  |----------------------------------------|
  '''))
  return auti
def atualizaDolar():
   arquivo = open('cotação_Dolar.txt', 'w')
   atualizacao = float(input('''
   Qual valor desejas colocar?12
    '''))
   arquivo.write(str(atualizacao))
   arquivo.close()
   print('Cotação atualizada com sucesso!')

  
def atualizaEuro(): 
  arquivo = open('cotação_Euro.txt', 'w') 
  atualizacao = float(input(''' 
  Qual valor desejas colocar?13 
   ''')) 
  arquivo.write(str(atualizacao)) 
  arquivo.close() 
  print('Cotação atualizada com sucesso!')

def atualizaPeso():
    arquivo = open('cotação_Peso.txt', 'w')
    atualizacao = float(input('''
    Qual valor desejas colocar?14
     '''))
    arquivo.write(str(atualizacao))
    arquivo.close()
    print('Cotação atualizada com sucesso!')
   
def selecaomoedas():
  dindin = int(input('''
  |-------------------------------|
  | 1 - Voltar pra Menu Principal | 
  | 2 - Converter Dolar para Real | 
  | 3 - Converter Euro para Real  |
  | 4 - Converter Peso para Real  |
  | 99 - Desligar sistema         |
  |-------------------------------|
  ''')) 
  return dindin


def convertDolar():
  while True:
    arquivo = open('cotação_Dolar.txt', 'r')
    cotaAtual = float(arquivo.readline())
    quanEuro = float(input('''Então amigo quantos Doláres tens?
  '''))
    valorconvert = quanEuro * cotaAtual
    print('''Aqui estas seus Doláres convertidos em reais:''' )
    return valorconvert

def convertEuro():
  while True:
    arquivo = open('cotação_Euro.txt', 'r')
    cotaAtual = float(arquivo.readline())
    quanEuro = float(input('''Então amigo quantos Euros tens?
  '''))
    valorconvert = quanEuro * cotaAtual
    print('''Aqui estas seus Euros convertidos em reais:''' )
    return valorconvert

def convertPESADAO():
  while True:
    arquivo = open('cotação_Peso.txt', 'r')
    cotaAtual = float(arquivo.readline())
    quanPeso = float(input('''Então amigo quantos Peso tens?
  '''))
    valorconvert = quanPeso * cotaAtual
    print('''Aqui estas seus Peso convertidos em reais:''' )
    return valorconvert
 


def desligando():
  print('''
          _________________________________
         |_________________________________|
         |                                 |
         |   Desligando o sistema....      |
         |---------------------------------|
         | Feito por Breno Teixeira        |
         |_________________________________|
          
       ''')
  return 0
    

   
  
 
