import globalsFunction as funcoes

while True: 
   selecaomoedas = funcoes.menuprincipal()
    
   if selecaomoedas == 1:
     din = funcoes.selecaomoedas()
    
     if din == 2: 
      valorconvert = funcoes.convertDolar()
      print (valorconvert)

     elif din == 3:  
      valorconvert = funcoes.convertEuro()
      print (valorconvert)

     elif din == 4:  
      valorconvert = funcoes.convertPESADAO()
      print (valorconvert)

     elif din  == 99:
      print("Desligando o sistema.")
      break
   if selecaomoedas == 2:
      auti = funcoes.selecaoatumoeda()
      
      if  auti == 1:
        funcoes.atualizaDolar()
      
      if  auti == 2:
       funcoes.atualizaEuro()
    
      if auti == 3:
       funcoes.atualizaPeso()
         
      if auti  == 99:
       print('''
          _________________________________
         |_________________________________|
         |                                 |
         |   Desligando o sistema....      |
         |---------------------------------|
         | Feito por Breno Teixeira        |
         |_________________________________|
          
       ''')
       break